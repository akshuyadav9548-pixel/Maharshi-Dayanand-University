import React, { useState } from 'react';
import { GraduationCap, AlertCircle, Search } from 'lucide-react';

export default function App() {
  const [rollNumber, setRollNumber] = useState('');
  const [registrationNumber, setRegistrationNumber] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!rollNumber || !registrationNumber) {
      setError('Please enter both Roll Number and Registration Number.');
      return;
    }

    if (rollNumber === '7091195' && registrationNumber === '2311172018') {
      window.open('https://drive.google.com/file/d/1eekv3bNDzTBQOYdkxjhLM5Vv88c8-azk/view', '_blank');
    } else {
      setError('Invalid Roll Number or Registration Number');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      {/* Header */}
      <header className="bg-[#003366] text-white shadow-md border-b-4 border-yellow-500">
        <div className="max-w-5xl mx-auto px-4 py-4 flex flex-col sm:flex-row items-center justify-center sm:justify-start gap-3">
          <div className="bg-white p-2 rounded-full">
            <GraduationCap className="w-8 h-8 text-[#003366]" />
          </div>
          <div className="text-center sm:text-left">
            <h1 className="text-xl sm:text-2xl font-bold tracking-wide uppercase">Maharshi Dayanand University</h1>
            <p className="text-blue-200 text-sm">Rohtak, Haryana (A+ Grade University)</p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-grow flex items-center justify-center p-4 py-12">
        <div className="bg-white w-full max-w-md rounded-xl shadow-xl border border-gray-200 overflow-hidden">
          {/* Card Header */}
          <div className="bg-blue-50 border-b border-blue-100 px-6 py-5">
            <h2 className="text-xl font-semibold text-[#003366] text-center uppercase tracking-wide">Result Portal</h2>
          </div>

          {/* Card Body */}
          <div className="p-6 sm:p-8">
            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <label htmlFor="rollNumber" className="block text-sm font-semibold text-gray-700 mb-1.5">
                  Roll Number <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="rollNumber"
                  value={rollNumber}
                  onChange={(e) => setRollNumber(e.target.value)}
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003366] focus:border-[#003366] outline-none transition-colors text-gray-900"
                  placeholder="Enter your Roll Number"
                />
              </div>

              <div>
                <label htmlFor="registrationNumber" className="block text-sm font-semibold text-gray-700 mb-1.5">
                  Registration Number <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="registrationNumber"
                  value={registrationNumber}
                  onChange={(e) => setRegistrationNumber(e.target.value)}
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003366] focus:border-[#003366] outline-none transition-colors text-gray-900"
                  placeholder="Enter your Registration Number"
                />
              </div>

              {error && (
                <div className="flex items-start gap-2.5 text-red-700 bg-red-50 p-3.5 rounded-lg text-sm border border-red-200">
                  <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
                  <p className="font-medium">{error}</p>
                </div>
              )}

              <button
                type="submit"
                className="w-full bg-[#003366] hover:bg-blue-900 text-white font-semibold py-3 px-4 rounded-lg transition-colors flex items-center justify-center gap-2 mt-4 shadow-md"
              >
                <Search className="w-5 h-5" />
                Check Result
              </button>
            </form>
          </div>
          
          {/* Card Footer */}
          <div className="bg-slate-50 px-6 py-4 border-t border-gray-200 text-center text-xs text-slate-500">
            Please enter your exact Roll Number and Registration Number as printed on your admit card/hall ticket.
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 py-6 text-center text-sm border-t border-slate-800">
        <p>&copy; {new Date().getFullYear()} Maharshi Dayanand University, Rohtak. All rights reserved.</p>
        <p className="mt-1 text-xs text-slate-500">Designed for mobile and desktop.</p>
      </footer>
    </div>
  );
}
